from PyDAIR.utils import *
from PyDAIR.seq import *
from PyDAIR.io import *
from PyDAIR.stats import *
from PyDAIR.plot import *
from PyDAIR.app import *

'''
        toC,tueaeoece                 yy,iehsterW.k
     uo.huseunaeSaeteoppo          tohurtle2gesotrair
   souas3ytiraearavl.lweatI     s,haheelsnbe,mbtsaamche
 epktienvmlypm2dtmtcceTe.amb   rvlsattm,rcnl?emIcunlolwoI
Bybho,ahf,rafehhWaewmwrleveds.ethdlshteel?srliaoEen.uhc,e,
meotvio'lntm'.wlcteeaa?prmwkpeaemsrttIe3rehlveoeramfarornmA
z8NiIl"o"tagtmaoieavhxthoutwsimtnakl'I'tsermsdhoaavkselmass
lonvsn't'arrreaAut3arahesyhvetrtrrfwdsasutesoteusrlk0,lEtte
v2s,'srnomWn'k'l'wmh'p'h'E'w0aei'a'o'E'oimwea'a'era'e'oh.py
vo,srt'I'oagb,'u'ore'e'brt',','.'.hw'o',gee'gmes-thIubl'kcB
 14elo'?'taiep'i'es,'A'ywhs.'d'ttmoe'C',shx'anxrataatrt'am
  De.d'e'ywaoc','slo'x'baa'I'n'e'hho'r'tnvart'ncv.soi'Ira
   cen'e'haaem'a,suewh'a'h'eokay'w'w'8'tehtam.wa'm'eooeg
    wootmeeslArety.c,naswassniBagp.,mcuotehtytottTtovei
      IutvBeeataeA'h'ad'u'mrasIhsvmyrehaDeegwaoahutav
        DvvNneie'hgyttItmei'e.i,eceuhuaaetmywimtaum
           htlp?'epiecwws,e'lt0,3ueshhcDttsrmefar
              rNue'emcixs'mhoymwststssratDktwo
                 uTc'a'hoetran,el-meorfre.
                    t,h..sghTiahhargsht
                       ol,raihmtueim
                           ehtla,
                             hg
'''
